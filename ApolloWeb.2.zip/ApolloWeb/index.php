<!DOCTYPE html>
<html>
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>APOLLO</title>
		<style>
			.error {color: #FF0000;}
		</style>
	<script type="text/javascript">
		var counter = 0;

		function moreSongs()
		{
			counter++;
			var newSongs = document.getElementById("readroot").cloneNode(true);
			newSongs.id = '';
			newSongs.style.display = 'block';
			var newSong = newFields.childNodes;
			for(var i = 0; i<newSong.length;i++)
			{
				var theName = newSong[i].name;
				if(theName)
					newSong[i].name = theName + counter;
			}
			var insertHere = document.getElementById("writeroot");
			insertHere.parentNode.insertBefore(newSongs, insertHere);
		}

		window.onload = moreSongs();
		
	</script>
</head>
<body>
<?php 
require_once 'Model/Artist.php';
require_once 'Model/Album.php';
require_once 'Model/Song.php';
require_once 'Model/HAS.php';
require_once 'Persistence/PersistenceApollo.php';

session_start();

//Retrieve data from the model
$pm = new PersistenceApollo();
$has = $pm->loadDataFromStore();

?>
<div id="readroot" style="display: none">
	<input type="button" value="Remove Song" onclick="this.parentNode.parentNode.removeChild(this.parentNode)"/>
    <input type="file" name="music"  id="audio"/>
    
    <p>Song Title <input type="text" name="song_name"/>
    <span class="error">
    <?php 
    if(isset($_SESSION['errorSongName']) && !empty($_SESSION['errorSongName']))
    {
    	echo " * " . $_SESSION['errorSongName'];
    }
    ?>
    </span></p>
    
    <p>Song Artist <input type="text" name="song_artist"/>
    <span class="error">
    <?php 
    if(isset($_SESSION['errorSongArtist']) && !empty($_SESSION['errorSongArtist']))
    {
    	echo " * " . $_SESSION['errorSongArtist'];
    }
    ?>
    </span></p>
    
    <p>Song Duration <input type="text" name="song_duration" value="<?php echo "MM:SS"; ?>"/>
    <span class="error">
    <?php 
    if(isset($_SESSION['errorSongDuration']) && !empty($_SESSION['errorSongDuration']))
    {
    	echo " * " . $_SESSION['errorSongDuration'];
    }
    ?>
    </span></p>
    
    <p>Song Genre <input type="text" name="song_genre"/>
    <span class="error">
    <?php 
    if(isset($_SESSION['errorSongGenre']) && !empty($_SESSION['errorSongGenre']))
    {
    	echo " * " . $_SESSION['errorSongGenre'];
    }
    ?>
    </span></p>
    
    <p>Album Track Number <input type="text" name="song_num" value="<?php echo "# Track Number"?>"/>
    <span class="error">
    <?php 
    if(isset($_SESSION['errorSongNum']) && !empty($_SESSION['errorSongNum']))
    {
    	echo " * " . $_SESSION['errorSongNum'];
    }
    ?>
    </span></p>
    
</div>

<form method="POST" action="Actions/uploadAlbum.php" enctype="multipart/form-data">
		<span id="writeroot"></span>
<p>Album Title <input type="text" name="album_name"/>
<span class="error">
<?php 
if(isset($_SESSION['errorAlbumName']) && !empty($_SESSION['errorAlbumName']))
{
	echo " * " . $_SESSION['errorAlbumName'];
}
?>
</span></p>

	 <input type="button" onclick="moreSongs()" value=" + Song " />
	 <input type="submit" value="Add Album" name="submit"/>

</form>
      
   </body>
</html>