package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.border.MatteBorder;

import controller.createAlbum;
import model.Album;
import model.Artist;

import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JSpinner;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AddAlbum extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField txtDdmmyyyy;
	private JLabel lblNewLabel;
	private JTextField textField_2;
	private JButton btnNewButton_1;
	private static JPanel panel;
	/**
	 * Launch the application.
	 */
	public static void setup(JPanel panelIN) {
		panel = panelIN;
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddAlbum frame = new AddAlbum();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddAlbum() {
		setVisible(true);
		setResizable(false);
		setTitle("Add Album");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 525, 274);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaptionBorder);
		contentPane.setBorder(null);
		setContentPane(contentPane);
		
		JLabel lblAlbumName = new JLabel("Album Name");
		lblAlbumName.setForeground(new Color(0, 0, 128));
		lblAlbumName.setBackground(Color.PINK);
		
		textField = new JTextField();
		textField.setColumns(10);
		
		JLabel lblArtistName = new JLabel("Artist Name");
		lblArtistName.setBackground(new Color(0, 0, 0));
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		
		JLabel lblReleaseDate = new JLabel("Release Date");
		lblReleaseDate.setBackground(new Color(0, 0, 0));
		
		txtDdmmyyyy = new JTextField();
		txtDdmmyyyy.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				txtDdmmyyyy.setText("");
			}
		});

		txtDdmmyyyy.setText("YYYY-MM-DD");
		txtDdmmyyyy.setToolTipText("YYYY-MM-DD");

		txtDdmmyyyy.setColumns(10);
		
		JButton btnNewButton = new JButton("Create Album");
		btnNewButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {

				createAlbum album = new createAlbum(textField.getText(), textField_1.getText(),
						txtDdmmyyyy.getText(),textField_2.getText());
				
				if(!album.checkVoids())
				{
					error.setup("Cannot have empty fields!"); 
				}	
				else if (!album.checkFormat()){
					error.setup("Incorrect song number format!");
				}
				else if(!album.checkDate()){
					error.setup("Incorrect date format!");
				}
				Artist art = album.getArtist();
				Album alb = album.getAlbum();
				contentPane.setOpaque(false);
				btnNewButton.setEnabled(false);
				AddSong.setup(alb,art);
			}
		});
		
		lblNewLabel = new JLabel("Number of Songs");
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		
		btnNewButton_1 = new JButton("Refresh window");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			dispose();
			panel.revalidate();
			panel.repaint();
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(150)
							.addComponent(btnNewButton)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnNewButton_1)
							.addGap(51))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(30)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(lblAlbumName)
									.addPreferredGap(ComponentPlacement.RELATED, 108, Short.MAX_VALUE)
									.addComponent(textField, GroupLayout.PREFERRED_SIZE, 223, GroupLayout.PREFERRED_SIZE))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(lblArtistName)
										.addComponent(lblNewLabel)
										.addComponent(lblReleaseDate))
									.addPreferredGap(ComponentPlacement.RELATED, 77, Short.MAX_VALUE)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
										.addComponent(textField_1, GroupLayout.DEFAULT_SIZE, 223, Short.MAX_VALUE)
										.addComponent(txtDdmmyyyy)
										.addComponent(textField_2))))))
					.addGap(65))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(3)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblAlbumName)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblArtistName))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(txtDdmmyyyy, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblReleaseDate))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel))
					.addGap(50)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton)
						.addComponent(btnNewButton_1))
					.addGap(31))
		);
		contentPane.setLayout(gl_contentPane);
	}

}
