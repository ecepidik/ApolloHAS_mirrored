package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class error {

	private JFrame frame;
	public static String errorMessage;
	/**
	 * Launch the application.
	 */
	public static void setup(String string) {
		error.errorMessage = string;
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					error window = new error();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public error() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 846, 267);
		frame.getContentPane().setLayout(null);
		
		JLabel lblCannotHaveEmpty = new JLabel(errorMessage);
		lblCannotHaveEmpty.setHorizontalTextPosition(SwingConstants.CENTER);
		lblCannotHaveEmpty.setHorizontalAlignment(SwingConstants.CENTER);
		lblCannotHaveEmpty.setFont(new Font("Tahoma", Font.BOLD, 44));
		lblCannotHaveEmpty.setForeground(Color.RED);
		lblCannotHaveEmpty.setBounds(-2, 16, 826, 106);
		frame.getContentPane().add(lblCannotHaveEmpty);
		
		JButton btnNewButton = new JButton("Ok");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.setVisible(false);
			}
		});
		btnNewButton.setBounds(259, 168, 115, 29);
		frame.getContentPane().add(btnNewButton);
	}
}
