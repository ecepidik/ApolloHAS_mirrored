package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Panel;

import javax.swing.JSeparator;
import javax.swing.JToggleButton;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import model.HAS;
import persistence.PersistenceHAS;
import persistence.PersistenceXStream;

import javax.swing.UIManager;
import java.awt.Color;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;

import javax.swing.JList;
import javax.swing.ListSelectionModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import java.awt.Scrollbar;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class HASViewManager {

	private JFrame frmApollo;
	private JList list;

	/**
	 * Launch the application.
	 */
	public static void setup() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HASViewManager window = new HASViewManager();
					window.frmApollo.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public HASViewManager() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmApollo = new JFrame();
		frmApollo.setTitle("Apollo");
		frmApollo.setBounds(100, 100, 1045, 662);
		frmApollo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmApollo.getContentPane().setLayout(new BoxLayout(frmApollo.getContentPane(), BoxLayout.X_AXIS));

		
			PersistenceHAS.loadEventRegistrationModel();
			HAS hs = HAS.getInstance();
			String[] albumNames = new String[hs.getAlbum().size()];
			DefaultListModel listmodel = new DefaultListModel();
			for (int i = 0; i < hs.getAlbum().size(); i++) {
				albumNames[i] = hs.getAlbum(i).getName();
				listmodel.addElement(hs.getAlbum(i).getName());
			}
		
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		frmApollo.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblLibrary = new JLabel("Library");
		lblLibrary.setBounds(6, 22, 169, 54);
		panel.add(lblLibrary);
		lblLibrary.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 44));
		
		JSeparator separator = new JSeparator();
		separator.setBounds(6, 74, 179, 25);
		panel.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(6, 169, 169, 76);
		panel.add(separator_1);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(6, 350, 179, 57);
		panel.add(separator_2);
		
		JSeparator separator_3 = new JSeparator();
		separator_3.setBounds(6, 528, 179, 46);
		panel.add(separator_3);
		
		this.list = new JList(listmodel);
		list.setFont(new Font("Times New Roman", Font.ITALIC, 28));
		list.setBackground(SystemColor.control);
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		list.setBounds(202, 96, 646, 259);
		panel.add(list);
		
		JToggleButton tglbtnNewToggleButton = new JToggleButton("Albums");
		tglbtnNewToggleButton.setSelected(true);;
		tglbtnNewToggleButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				String[] songNames = new String[hs.getAlbum().size()];
				for (int i = 0; i < hs.getAlbum().size(); i++) {
					songNames[i] = hs.getAlbum(i).getName();
					}
				list.setListData(songNames);

				panel.revalidate();
				panel.repaint();
				
			}
		});
		
		tglbtnNewToggleButton.setBounds(6, 93, 163, 29);
		panel.add(tglbtnNewToggleButton);
		
		JToggleButton tglbtnNewToggleButton_1 = new JToggleButton("Songs");
		tglbtnNewToggleButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				String[] albumNames = new String[hs.getSong().size()];
				for (int i = 0; i < hs.getSong().size(); i++) {
					albumNames[i] = hs.getSong(i).getName();
					
				}
				list.setListData(albumNames);
				panel.revalidate();
				panel.repaint();
				
			}
		});
		tglbtnNewToggleButton_1.setBounds(6, 261, 163, 29);
		panel.add(tglbtnNewToggleButton_1);
		
		JToggleButton tglbtnNewToggleButton_2 = new JToggleButton("Playlists");
		tglbtnNewToggleButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String[] playlistNames = new String[hs.getPlaylist().size()];
				for (int i = 0; i < hs.getPlaylist().size(); i++) {
					playlistNames[i] = hs.getAlbum(i).getName();
					}
				list.setListData(playlistNames);

				panel.revalidate();
				panel.repaint();
				
			}
		});
		tglbtnNewToggleButton_2.setBounds(6, 439, 163, 29);
		panel.add(tglbtnNewToggleButton_2);
		
		JButton btnAddAlbums = new JButton("Add Albums");
		btnAddAlbums.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AddAlbum.setup(panel);
			}
		});
		btnAddAlbums.setBounds(6, 138, 163, 29);
		panel.add(btnAddAlbums);
		
		JButton btnNewButton = new JButton("Add Songs");
		btnNewButton.setBounds(6, 305, 163, 29);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Create Playlists");
		btnNewButton_1.setBounds(6, 483, 163, 29);
		panel.add(btnNewButton_1);
		
		
		
		JLabel lblNewLabel = new JLabel("Albums");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 44));
		
		lblNewLabel.setBounds(366, 22, 290, 54);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Rooms");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 44));
		lblNewLabel_1.setBounds(829, 37, 179, 38);
		panel.add(lblNewLabel_1);
		
		tglbtnNewToggleButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tglbtnNewToggleButton_1.setSelected(false);
				tglbtnNewToggleButton_2.setSelected(false);
				lblNewLabel.setText("Albums");
			}


		});
		
		tglbtnNewToggleButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tglbtnNewToggleButton.setSelected(false);
				tglbtnNewToggleButton_2.setSelected(false);
				lblNewLabel.setText("Songs");
			}
		});
		tglbtnNewToggleButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				tglbtnNewToggleButton.setSelected(false);
				tglbtnNewToggleButton_1.setSelected(false);
				lblNewLabel.setText("Playlists");
			}
		});
		
	}
}
