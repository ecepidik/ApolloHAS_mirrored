package main;




import java.io.IOException;
import java.io.InputStream;

import persistence.PersistenceHAS;
import view.HASViewManager;
import view.PlayMusic;

public class HAS {
	public static void main(String[] args) {
		
		HASViewManager.setup();
		PlayMusic.playSample();

	}


}
