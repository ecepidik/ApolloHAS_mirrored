package controller;

import java.sql.Date;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import model.Album;
import model.Artist;
import model.HAS;
import model.Song;
import persistence.PersistenceXStream;

public class createSong {
	private Artist artist;
	private Album album;
	private String songName;
	
	private String durationString;
	java.util.Date duration;
	private String genre;
	
	private int trackNumber;
	private String trackString;
	Song aSong;
	
	public createSong(Album alb, Artist artist, String name,String duration, String genre, String trackNum){
		this.artist = artist;
		this.songName = name;
		this.durationString = duration;
		this.genre = genre;
		this.trackString = trackNum;
		this.album = alb;
		
	}
	public boolean checkVoids() {
		if(songName.length()==0 || songName.trim().length() == 0){
			return false;
		}
		else if(durationString.length()==0 || durationString.trim().length() == 0){
			return false;
		}

		else if(genre.length()==0 || genre.trim().length() == 0){
			return false;
		}
		else if(trackString.length()==0 || trackString.trim().length() == 0){
			return false;
		}
		return true;
	}
	public boolean checkFormat() {
		trackNumber =0;
		try {
			trackNumber  = Integer.parseInt(trackString);

		} catch (NumberFormatException e) {
			return false;
		}		
		return true;
	}
	public boolean checkTimeFormat(){
		try {
			String time = durationString;
			Time length = new Time(0);
			length = Time.valueOf("00:"+durationString);
			aSong = new Song(songName, length, genre, trackNumber, artist);
		} catch (Exception e ) {
			return false;
		}
		album.addSongAt(aSong,trackNumber);
		
		saveSong();
		saveAlbum();
		
		return true;
	}
	private void saveSong() {
		
		HAS hs = HAS.getInstance();
		
		hs.addSong(aSong);
		
		PersistenceXStream.saveToXMLwithXStream(hs);
	
	}
	private void saveAlbum() {
		HAS hs = HAS.getInstance();
		
		hs.addAlbum(album);
		
		PersistenceXStream.saveToXMLwithXStream(hs);
	}
	
}
