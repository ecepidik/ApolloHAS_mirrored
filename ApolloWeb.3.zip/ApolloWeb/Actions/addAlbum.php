<?php
require_once __DIR__.'/../Controller/controller.php';

session_start();

$c =  new controller();
try
{
	$c->createAlbum($_POST['album_name'], $_POST['album_date'], $_POST['album_artist']);
	$_SESSION["errorAlbumName"] = "";
	$_SESSION["errorAlbumDate"] = "";
	$_SESSION["errorAlbumArtist"] = "";
}
catch (Exception $e)
{
	//**GOING TO HAVE TO COME BACK HERE**
	$_SESSION["errorAlbumName"] = $e->getMessage();
	if($_SESSION["errorAlbumName"] != "")
	{
		echo '<meta http-equiv="refresh" content="0; url=/ApolloWeb/Actions/uploadAlbum.php"/>';
	}
	else
	{
		echo '<meta http-equiv="refresh" content="0; url=/ApolloWeb/Actions/uploadSongs.php"/>';
	}
}
?>
