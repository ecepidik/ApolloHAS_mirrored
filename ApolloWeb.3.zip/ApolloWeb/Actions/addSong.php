<?php
require_once __DIR__.'/../Controller/controller.php';

session_start();

$c =  new controller();
try
{
	$c->createSong($_POST['song_name'], $_POST['song_duration'], $_POST['song_genre'], $_POST['song_num'], $_POST['song_artist']);
	$_SESSION["errorSongName"] = "";
	$_SESSION["errorSongDuration"] = "";
	$_SESSION["errorSongArtist"] = "";
	$_SESSION["errorSongNum"] = "";
	$_SESSION["errorSongGenre"] = "";
}
catch (Exception $e)
{
	//**GOING TO HAVE TO COME BACK HERE**
	$_SESSION["errorSongName"] = $e->getMessage();
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="refresh" content="0; url=/ApolloWeb/" />
	</head>
</html>