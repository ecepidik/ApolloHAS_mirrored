<!DOCTYPE html>
	<html>
		<head>
			<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
			<title>|Add Album Songs|</title>
			<style>
				.error {color: #FF0000;}
			</style>
<script type="text/javascript">

var counter = 0;

function moreSongs()
{
	counter++;
	var newSongs = document.getElementById("readroot").cloneNode(true);
	newSongs.id = '';
	newSongs.style.display = 'block';
	var newSong = newSongs.childNodes;
	for(var i = 0; i<newSong.length;i++)
	{
		var theName = newSong[i].name;
		if(theName)
			newSong[i].name = theName + counter;
	}
	var insertHere = document.getElementById("writeroot");
	insertHere.parentNode.insertBefore(newSongs, insertHere);
}

window.onload = moreSongs;

</script>
</head>
<body>
<?php
require_once __DIR__.'/../Persistence/PersistenceApollo.php';
require_once __DIR__.'/../Model/Artist.php';
require_once __DIR__.'/../Model/Album.php';
require_once __DIR__.'/../Model/Song.php';
require_once __DIR__.'/../Model/HAS.php';

session_start();

//Retrieve data from the model
$pm = new PersistenceApollo();
$has = $pm->loadDataFromStore();

if(isset($_FILES['audio']))
{
	$target_dir = "ApolloWeb/uploads/";
	$target_file = $target_dir . basename($_FILES['audio']['name']);
	$audioFileType = pathinfo($target_file, PATHINFO_EXTENSION);
	$errors= array();
	$file_name = $_FILES['audio']['name'];
	$file_size =$_FILES['audio']['size'];
	$file_tmp =$_FILES['audio']['tmp_name'];
	$file_type=$_FILES['audio']['type'];
	$file_ext=strtolower(end(explode('.',$_FILES['audio']['name'])));

	$expensions= array("wav","mp3","mp4","m4a","aiff","aac","m4p","wma");

	if(in_array($file_ext,$expensions)=== false)
	{
		$errors[]="Extension not allowed. Please choose an appropriate audio file.";
	}

	if($file_size > 128000000)
	{
		$errors[]='Audio file too large. Must be less than 128 MB.';
	}

	if(file_exists($target_file))
	{
		$errors[]='Audio file was already uploaded.';
	}

	if(empty($errors)==true)
	{
		move_uploaded_file($file_name, $target_file);
		include 'addSong.php';
		echo "File uploaded";
	}
	else
	{
		print_r($errors);
	}
}
?>

<div id="readroot" style="display: none">
	<input type="button" value="Remove Song" onclick="this.parentNode.parentNode.removeChild(this.parentNode)"/>
    <input type="file" name="audio"  id="audio"/>
    
    <p>Song Title <input type="text" name="song_name"/>
    <span class="error">
    <?php 
    if(isset($_SESSION['errorSongName']) && !empty($_SESSION['errorSongName']))
    {
    	echo " * " . $_SESSION['errorSongName'];
    }
    ?>
    </span></p>
    
    <p>Song Artist <input type="text" name="song_artist"/>
    <span class="error">
    <?php 
    if(isset($_SESSION['errorSongArtist']) && !empty($_SESSION['errorSongArtist']))
    {
    	echo " * " . $_SESSION['errorSongArtist'];
    }
    ?>
    </span></p>
    
    <p>Song Duration <input type="text" name="song_duration" value="<?php echo "MM:SS"; ?>"/>
    <span class="error">
    <?php 
    if(isset($_SESSION['errorSongDuration']) && !empty($_SESSION['errorSongDuration']))
    {
    	echo " * " . $_SESSION['errorSongDuration'];
    }
    ?>
    </span></p>
    
    <p>Song Genre <input type="text" name="song_genre"/>
    <span class="error">
    <?php 
    if(isset($_SESSION['errorSongGenre']) && !empty($_SESSION['errorSongGenre']))
    {
    	echo " * " . $_SESSION['errorSongGenre'];
    }
    ?>
    </span></p>
    
    <p>Song Track Number <input type="text" name="song_num" value="<?php echo "# Track Number"?>"/>
    <span class="error">
    <?php 
    if(isset($_SESSION['errorSongNum']) && !empty($_SESSION['errorSongNum']))
    {
    	echo " * " . $_SESSION['errorSongNum'];
    }
    ?>
    </span></p>
</div>
<form method="post" action="uploadSongs.php" enctype="multipart/form-data">
		<span id="writeroot"></span>
		
	 	<input type="button" onclick="moreSongs()" value=" + Song " />
		 <input type="submit" value="Add Songs" name="submit"/>

</form>
</body>

</html>