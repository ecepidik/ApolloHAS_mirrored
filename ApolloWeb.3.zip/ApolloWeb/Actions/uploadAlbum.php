<!DOCTYPE html>
	<html>
		<head>
			<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
			<title>APOLLO :: Add Album</title>
			<style>
				.error {color: #FF0000;}
			</style>

		</head>
		<body>
<?php
require_once __DIR__.'/../Persistence/PersistenceApollo.php';
require_once __DIR__.'/../Model/Artist.php';
require_once __DIR__.'/../Model/Album.php';
require_once __DIR__.'/../Model/Song.php';
require_once __DIR__.'/../Model/HAS.php';

session_start();

//Retrieve data from the model
$pm = new PersistenceApollo();
$has = $pm->loadDataFromStore();

?>		
	<form method="post" action="addAlbum.php">
	
		<p>Album Title <input type="text" name="album_name"/>
		<span class="error">
		<?php 
		if(isset($_SESSION['errorAlbumName']) && !empty($_SESSION['errorAlbumName']))
		{
			echo " * " . $_SESSION['errorAlbumName'];
		}
		?>
		</span></p>

		<p>Album Release Date <input type="text" name="album_date" value="<?php echo date('Y-m-d');?>"/>
		<span class="error">
		<?php 
		if(isset($_SESSION['errorAlbumDate']) && !empty($_SESSION['errorAlbumDate']))
		{
			echo " * " . $_SESSION['errorAlbumDate'];
		}
		?>
		</span></p>
		
		<p>Album Artist <input type="text" name="album_artist"/>
		<span class="error">
		<?php 
		if(isset($_SESSION['errorAlbumArtist']) && !empty($_SESSION['errorAlbumArtist']))
		{
			echo " * " . $_SESSION['errorAlbumArtist'];
		}
		?>
		</span></p>
		
			 <input type="submit" value="Add Album" name="submit"/>
		
		</form>
		      
		   </body>
		</html>