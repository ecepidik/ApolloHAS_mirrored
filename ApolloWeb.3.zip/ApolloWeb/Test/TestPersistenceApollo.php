<?php
require_once'/Users/Charles-William/Documents/Coding/ApolloProject/ApolloWeb/Persistence/PersistenceApollo.php';
require_once'/Users/Charles-William/Documents/Coding/ApolloProject/ApolloWeb/Model/HAS.php';
require_once'/Users/Charles-William/Documents/Coding/ApolloProject/ApolloWeb/Model/Album.php';
require_once'/Users/Charles-William/Documents/Coding/ApolloProject/ApolloWeb/Model/Artist.php';

class TestPersistenceApollo extends PHPUnit_Framework_TestCase
{
	protected $pm;
	
	protected function setUp()
	{
		$this->pm = new PersistenceApollo();
	}
	
	protected function tearDown()
	{
	}
	
	public function testPersistence()
	{
		// 1. Create test data
		$has = HAS::getInstance();
		$artist = new Artist("Tame Impala");
		$album = new Album("Lonerism","2012-03-12",$artist);
		$has->addAlbum($album);
		
		// 2. Write all of the data
		$this->pm->writeDataToStore($has);
		
		// 3. Clear the data from memory
		$has->delete();
		
		$this->assertEquals(0, count($has->getAlbum()));
		$this->assertEquals(0, count($has->getArtist()));
		
		// 4. Load it back in
		$has = $this->pm->loadDataFromStore();
		
		// 5. Check that we got it back
		$this->assertEquals(1,count($has->getAlbum()));
		$myAlbum = $has->getAlbum_index(0);
		$this->assertEquals("Lonerism", $myAlbum->getName());
		$this->assertEquals("2012-03-12", $myAlbum->getDate());
		$this->assertEquals($artist, $myAlbum->getArtist());
	}

}